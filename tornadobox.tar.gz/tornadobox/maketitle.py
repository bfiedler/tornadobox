#!/usr/bin/env python
# 18 March 2025
from PIL import Image , ImageDraw ,  ImageFont
import os, sys, argparse

parser = argparse.ArgumentParser(description=" make a title PNG for png2mp4.py ")
parser.add_argument("inpng", help="text added to this PNG")
# Optional arguments
parser.add_argument("-o", dest="outpng", type=str, default="title.png", help="out PNG file name")
# Version argument
parser.add_argument("--version", action="version", version="0.1")
args = parser.parse_args()

# Open an Image
img = Image.open(args.inpng)

# Call draw Method to add 2D graphics in an image
I1 = ImageDraw.Draw(img)

# Custom font style and font size
myFont = ImageFont.truetype('FreeMono.ttf', 65)

# Add Text to an image, Edit as needed.
I1.text((10, 60), u"181 \u00D7 181 \u00D7 91", font=myFont, fill =(255, 0, 0))
I1.text((10, 120 ), u"\u03BC = 0.0001", font=myFont, fill =(255, 0, 0))
I1.text((10, 180), "f = 0.1", font=myFont, fill =(255, 0, 0))
I1.text((10, 240), "p: -4 -2 -1 -.5 ", font=myFont, fill =(0,255, 0))
I1.text((10, 300), "w: -.2 ", font=myFont, fill =(0,200,255 ))

# Display edited image
img.show()

# Save the edited image
permit='y'
check = os.path.exists(args.outpng)
if check:
    permit= input(args.outpng+' exists, overwrite? (y/n)')
if permit=='y':
    img.save(args.outpng)
    print(" image saved in ",args.outpng) 
