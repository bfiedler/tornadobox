#!/usr/bin/env python
# 18 March 2025
from glob import glob
import pyvista as pv
import numpy as np
import pickle
import sys,os

import argparse
# Define the argument parser
parser = argparse.ArgumentParser(description="pyvista pkl files from tornadobox")

# Positional arguments 
parser.add_argument("head", help="path to glob for pkl files")
parser.add_argument("pngdir", nargs='?', default='',help="path to directory for pngs")
#parser.add_argument("field", nargs='?', default="pp" , help="field to plot")

# Optional arguments
#parser.add_argument("-o", dest="oufn", type=str, default="", help="out image file name")
parser.add_argument("-i", dest="iv", type=str, default="", help="isovalues, in quotes")
parser.add_argument("-s", dest="show", action="store_true",  help="show plot")
parser.add_argument("-v", dest="verbose", action="store_true",  help="print more stuff")
parser.add_argument("-r", dest="show_rectangle", action="store_true",  help="plot rectangle on floor")
parser.add_argument("-hg", dest="show_hg", action="store_true",  help="plot grid on floor")
parser.add_argument("-vg", dest="show_vg", action="store_true",  help="plot grid in verical slice" )
parser.add_argument("-d", dest="show_domain", action="store_true",  help="plot domain box")
parser.add_argument("-b", dest="iso_b", action="store_true",  help="plot buoyancy isosurfaces")
parser.add_argument("-w", dest="iso_w", action="store_true",  help="plot w isosurfaces")
parser.add_argument("-c", dest="close", type=float, default=1., help="camera distance, try 1 and .2")
parser.add_argument("-z", dest="zaim", type=float, default=.4, help="camera aim at z")

# Version argument
parser.add_argument("--version", action="version", version="0.1")

# Parse arguments
args = parser.parse_args()
##################################################
files= glob(args.head+'*.pkl')
if len(files)==0: print("no pkl files found")
files.sort()
for file in files[0:]:
    print("read pkl file: ",file)
    if args.pngdir:
        oupn = args.pngdir+'/'+file.split('/')[-1][:-4]+'.png'
        print("aim for png file: ", oupn)
    else:
        args.show = True
    with open(file, 'rb') as pinf:
        pkl = pickle.load(pinf)
    x = pkl['x']
    y = pkl['y']
    z = pkl['z']
    u = pkl['u']
    v = pkl['v']
    w = pkl['w']
    p = pkl['p'] # in between grid points, not so useful for plotting
    pp = pkl['pp'] # for plotting
    print(x.shape)
    if args.verbose:
        for key in pkl.keys():
            if type(pkl[key])==type(pkl['x']):
                print(key,pkl[key].max(),pkl[key].min(),pkl[key].shape)
        print( pkl['parameters'])

    grid = pv.StructuredGrid(x, y, z)
    grid.point_data['pp'] = pkl['pp'].T.flatten()  
    grid.point_data['b'] = pkl['b'].T.flatten()  


    km,jm,im=x.shape
    mm=im//4
    mn=3*im//4
    grid2 = pv.StructuredGrid(x[:,mm:mn,mm:mn], y[:,mm:mn,mm:mn],z[:,mm:mn,mm:mn])
    ww=pkl['w'][:,mm:mn,mm:mn]
    grid2.point_data['w'] = ww.T.flatten()  

    if not args.show:
        plotter = pv.Plotter(off_screen=True,lighting='none')
    else:
        plotter = pv.Plotter(lighting='none')
    light = pv.Light()
    light.set_direction_angle(10, -60 )
#    light.ambient_color = 'green'  # Enable ambient light contribution, does not do anything?
    
    plotter.add_light(light)
#    plotter.enable_shadows()
    plotter.background_color = "black"

    if args.verbose:
        for i, light in enumerate(plotter.renderer.lights):
            print(f"Light {i}:")
            print(f"  Type: {light.light_type}")
            print(f"  Position: {light.position}")
            print(f"  Focal Point: {light.focal_point}")
            print(f"  Intensity: {light.intensity}")
            print(f"  Ambient: {light.ambient_color}")
            print(f"  Specular: {light.specular_color}")

    
    isovalues = [1.,.3,.05] # for buoyancy b
    if not args.iso_b: isovalues=[]
    for i, iso_value in enumerate(isovalues):
        contours = grid.contour([iso_value],scalars='b') 
        if contours.n_points > 0:
            if i==0:
                color = 'blue'
                opacity = .9
            elif i==1:
                color = 'purple'
                opacity = .7
            else:
                color='pink'
                opacity = .5
            plotter.add_mesh(contours, color=color, opacity=opacity)
        else:
            print(f"Skipping iso_value {iso_value}: No valid contours found.")


    isovalues=[-4.,-2.,-1.,-.5] # for pressure
#    isovalues=[-2.,-1.,-.5]
    for i, iso_value in enumerate(isovalues):
        contours = grid.contour([iso_value],scalars='pp') 
        if contours.n_points > 0:
            if i==0:
                color = 'cyan'
                opacity = 1.0 
            if i==1:
                color = 'red'
                opacity = .9
            elif i==2:
                color = 'yellow'
                opacity = .7
            else:
                color='white'
                opacity = .5
            plotter.add_mesh(contours, color=color, opacity=opacity)
        else:
            print(f"Skipping iso_value {iso_value}: No valid contours found.")

    isovalues=[-.2] # for w
    if not args.iso_w : isovalues=[]
    for i, iso_value in enumerate(isovalues):
        contours = grid2.contour([iso_value],scalars='w') 
        if contours.n_points > 0:
            if i==0:
                color = 'blue'
                opacity = 1.0 
            elif i==1:
                color = 'yellow'
                opacity = .8
            else:
                color='pink'
                opacity = .4
            plotter.add_mesh(contours, color=color, opacity=opacity)
        else:
            print(f"Skipping iso_value {iso_value}: No valid contours found.")

    if args.show_hg:
        themesh= pv.StructuredGrid(x[0,:,:],y[0,:,:],z[0,:,:])
        edges = themesh.extract_all_edges()
        plotter.add_mesh(edges,color="indigo", line_width=1)

    if args.show_vg:
        kmax,jmax,imax=x.shape
        jmid=(jmax+1)//2
        themesh= pv.StructuredGrid(x[:,jmid,:],y[:,jmid,:],z[:,jmid,:])
        edges = themesh.extract_all_edges()
        plotter.add_mesh(edges,color="green", line_width=1)

    # Add optional .4 x .4 rectangle on floor
    if args.show_rectangle:
        rectangle = pv.Plane(center=(0, 0, 0), i_size=.4, j_size=.4)
        plotter.add_mesh(rectangle, color="lightblue", show_edges=True)

    # Add optional domain box
    if args.show_domain:
        bbox = pv.Cube(bounds=(-2,2,-2,2,0,1))
        edges = bbox.extract_all_edges()
        plotter.add_mesh(edges, color='green', line_width=3)
            

    # Set custom camera position
    plotter.camera_position = [
        (0, -10 * args.close, 2 * args.close),
        (0, 0, args.zaim),
        (0, 0, 1)
    ]

    timestamp = "{:6.2f}".format( pkl['parameters']['time'] )
    plotter.add_text(timestamp,color='pink')
    if  args.show:
        print("Showing")
        plotter.show()
    else:
        plotter.show(screenshot=oupn)
        print("output to ",oupn)
print("Done")


