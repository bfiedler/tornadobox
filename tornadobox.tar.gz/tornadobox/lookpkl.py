#!/usr/bin/env python
import pickle, sys
pinfname = sys.argv[1]
pinf = open(pinfname,'rb')
pkl = pickle.load(pinf)
print(pkl.keys())
for k,v in pkl['parameters'].items():
    print(k,v)


