# assumes the following line already was executed:
# source /home/bfiedler/intel/oneapi/setvars.sh
ifx -o gridmaker gridmaker.f
rm box.size
ln -s box91.size box.size
ifx -o boxn91 boxn.f boxs.f 
ifx -o dubl91 dubl.f
ifx -o cubit cubit.f where.f90 
# compile higher resolution model:
rm box.size
ln -s box181.size box.size
ifx -o boxn181 boxn.f boxs.f 
