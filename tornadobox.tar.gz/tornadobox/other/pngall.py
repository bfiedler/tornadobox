#!/usr/bin/env python
from pkl_vis import * 
from glob import glob
import sys,os
head = sys.argv[1]
pngdir = sys.argv[2]
files= glob(head+'*.sav')
for file in files:
    pfile=file.replace('sav','pkl')
    cex = os.path.exists(pfile)
    print(file,pfile,cex)
    if not cex:
        command='./sav2pkl.py '+file
        print(command)
        os.system(command)
files= glob(head+'*.pkl')
files.sort()
for file in files[0:]:
    print(file)
    oupn=pngdir+'/'+file.split('/')[-1][:-4]+'.png'
    print(oupn)
    with open(file, 'rb') as pinf:
        pkl = pickle.load(pinf)
    x = pkl['x']
    y = pkl['y']
    z = pkl['z']
    for key in pkl.keys():
        if type(pkl[key])==type(pkl['x']):
            print(key,pkl[key].max(),pkl[key].min())
    print( pkl['parameters'])
    f='pp'
    if f=='pp':
        isov=[-1.,-.5]
        isov=[-4.,-2.,-1.]
    elif f=='w':
        isov=[.5,1.]
    grid = create_grid(x, y, z, pkl[f])
    plot_data(grid,isovalues=isov,outpng=oupn,zoom=.2,zaim=.4)
#    plot_data(grid,isovalues=isov,outpng="",zoom=1.)

