from __future__ import print_function
import numpy as np
import sys,pickle
from plotters import *

try:
    filename=sys.argv[1]
except:
    print( "specify .pkl file from command line")
    sys.exit()
    
pinf=open(filename,'rb')

pkl = pickle.load(pinf)

print( pkl.keys() )

for i in pkl['parameters'].items():
    print(i)

# Note the transpose .T is essential for mayavi, which requires the
# volumes to be indexed with the three idices in x,y,z order.
# for plotters.py requires z,y,x order, so we do not append the .T method here
x = pkl['x']
y = pkl['y']
z = pkl['z']
u = pkl['u']
v = pkl['v']
w = pkl['w']
pp = pkl['pp']
time = pkl['parameters']['time']
rei = pkl['parameters']['rei']
swirl = pkl['parameters']['swirl']

print('x', x.shape, x.max(), x.min() )
print('y', y.shape, y.max(), y.min() )
print('z', z.shape, z.max(), z.min() )
print('u', u.shape, u.max(), u.min() )
print('v', v.shape, v.max(), v.min() )
print('w', w.shape, w.max(), w.min() )
print('pp', pp.shape, pp.max(), pp.min() )

#############################################
        # xy plot of u,v and w at lower level:
#xyf = 'xy z={0:5.3f}  cori={1:6.3f} dcoef={2:9.2e}  dt={3:9.2e}   {4:d} {5:d} {6:d} '
#textxy=xyf.format(z[kpl,0,0],cori,dcoef,dt,ix,iy,iz)
kpl=10
vectordensity=4
xyf = 'xy   z={0:5.3f}   rei={1:10.3e}   swirl={2:10.3e}   vd={3:d}'
textxy=xyf.format(z[kpl,0,0],rei,swirl,vectordensity)
wpng = 'w%05d.png' % int(100*time+.5)
oneplot(x[kpl],y[kpl],w[kpl],outpng=wpng,
    plotcl=False,u=u[kpl],v=v[kpl],title='w',vd=1,
    time=time,speed=.5,lowc=-.65,hic=.65,nlev=13,text=textxy)
#oneplot(x[kpl],y[kpl],w[kpl],outpng=wpng,
#    plotcl=False,u=u[kpl],v=v[kpl],title='w',vd=4,
#    time=time,speed=.5,lowc=-.65,hic=.65,nlev=13,text=textxy)




