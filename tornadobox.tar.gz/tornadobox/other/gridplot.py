from __future__ import print_function
import sys,pickle
from pylab import *  #pylab is the same as matplotlib.pylab

try:
    filename=sys.argv[1]
except:
    print( "specify .pkl file from command line")
    sys.exit()
    
pinf=open(filename,'rb')

pkl = pickle.load(pinf)

print( pkl.keys() )

for i in pkl['parameters'].items():
    print(i)

# Note the transpose .T is essential for mayavi, which requires the
# volumes to be indexed with the three idices in x,y,z order.
# for plotters.py requires z,y,x order, so we do not append the .T method here
x = pkl['x']
y = pkl['y']
z = pkl['z']
u = pkl['u']
v = pkl['v']
w = pkl['w']

def drawgrid(xa,ya):
    xstretch=1. # means isotropic distances 
    guiheight=8.
    aspectRatio=float( (ya[-1,0]-ya[0,0])/(xa[0,-1]-xa[0,0]) )
    plotheight=.7 #fraction of GUI window
    plotwidth=xstretch*plotheight/aspectRatio #fraction of GUI window if guiasp=1.
    dw=.1 # side margin
    dbt=.15 #bottom margin (leaves room for text note)
    cw=0.
    guiwidth=(2*dw+plotwidth+2*cw)*guiheight
    guiasp=guiwidth/guiheight
    thefig=figure(figsize=(guiwidth,guiheight),facecolor='white')
    theaxes=thefig.add_axes([  dw/guiasp, dbt,  plotwidth/guiasp,  plotheight ],zorder=2.,frameon=False)
    theaxes.set_xlim( [  xa[0,0],xa[0,-1] ] )
    theaxes.set_ylim( [  ya[0,0],ya[-1,0] ] )
    im,jm= xa.shape
    grcol=[0,0,0]
    linewidth=.5
    for j in arange(0,jm):
        xl=xa[:,j]
        yl=ya[:,j]
    #   print xl,yl
        myline= Line2D(xl,yl,color=grcol,linewidth=linewidth)
        myline.set_aa(False)
        theaxes.add_line(myline)
    for i in arange(0,im):
        xl=xa[i,:]
        yl=ya[i,:]
    #   print xl,yl
        myline= Line2D(xl,yl,color=grcol,linewidth=linewidth)
        myline.set_aa(False)
        theaxes.add_line(myline)
drawgrid(x[0,:,:],y[0,:,:])
savefig('grid_xy.svg', dpi=144, facecolor='w', edgecolor='w', orientation='portrait')

ic=x.shape[-1]//2+1
drawgrid( x[:,ic,:], z[:,ic,:] )
savefig('grid_xz.svg', dpi=144, facecolor='w', edgecolor='w', orientation='portrait')
