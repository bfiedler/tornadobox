from __future__ import print_function
import numpy as np
import sys,pickle
from mayavi import mlab

try:
    filename=sys.argv[1]
except:
    print( "specify .pkl file from command line")
    sys.exit()
    
pinf=open(filename,'rb')

pkl = pickle.load(pinf)

print( pkl.keys() )

for i in pkl['parameters'].items():
    print(i)

# Note the transpose .T is essential for mayavi, which requires the
# volumes to be indexed with the three idices in x,y,z order.
x = pkl['x'].T
y = pkl['y'].T
z = pkl['z'].T
u = pkl['u'].T
v = pkl['v'].T
w = pkl['w'].T
pp = pkl['pp'].T

print('x', x.shape, x.max(), x.min() )
print('y', y.shape, y.max(), y.min() )
print('z', z.shape, z.max(), z.min() )
print('u', u.shape, u.max(), u.min() )
print('v', v.shape, v.max(), v.min() )
print('w', w.shape, w.max(), w.min() )
print('pp', pp.shape, pp.max(), pp.min() )

#############################################

# for checking is a sphere is rendered as a sphere:
#bs = pp*0 + np.exp(-x*x -y*y -(z-.25)**2 )
#print('bs', bs.shape, bs.max(), bs.min() )
#mlab.contour3d(z,y,x,bs,contours=[.95,])
#mlab.contour3d(z,y,x,bs,contours=[.9],opacity=.5)

mlab.contour3d(x,y,z,pp,contours=[-1.,],color=(1.,0.,0.),opacity=.8)
mlab.contour3d(x,y,z,pp,contours=[-.5],color=(0.,1.,0.),opacity=.5)
mlab.outline(extent=[-.25,.25,-.25,.25,0,.5])
j=5
k=30
s=4
mlab.quiver3d(x[::s,::s,j::k],y[::s,::s,j::k],z[::s,::s,j::k],
u[::s,::s,j::k],v[::s,::s,j::k],w[::s,::s,j::k] , scale_mode='vector') 
 
mlab.vectorbar(title='speed')

mlab.show()

# mlab.savefig('foo.png', size=(1000, 1000))



