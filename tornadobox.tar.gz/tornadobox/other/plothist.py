#!/usr/bin/env python
#plots time histories of maxima stored in eza.hist files in subdirectories
#example of usage:
#>  plothist.py -o both.png exp1_subdirectory exp2_subdirectory
#To see a GUI, and not maka a PNG,
#>  plothist.py exp1_subdirectory exp2_subdirectory
import sys,re, getopt, math
from pylab import *  #pylab is the same as matplotlib.pylab
options, args= getopt.getopt(sys.argv[1:],'dt:p:o:a:b:c:')
dotsperinch=72
outputfile=""
customtitle=False
x1=None
x2=None
bar=None
ymax=5.
fontsize='large'
indir=False
for theopt,thearg in options:
	if theopt=='-d': 
		indir=True	
	elif theopt=='-o': 
		outputfile=thearg	
	elif theopt=='-p': 
		dotsperinch=float(thearg)	
	elif theopt=='-a': 
		x1=float(thearg)	
	elif theopt=='-b': 
		x2=float(thearg)	
	elif theopt=='-c': 
		bar=float(thearg)	
	elif theopt=='-t': 
		customtitle=True
		thetitle=thearg
	else:
		print("What is ",theopt,"?")
#hold(True)
directories=args
legendlabs=[]
markers=['','--',':','']
nf=0
for directory in directories:
	if indir:
		inf=open(directory+'/'+directory+'.hist','r')
	else:
		inf=open(directory+'.hist','r')
	all=inf.readlines()
	inf.close()
	#hist=all[102:]
	hist=all
	t=[]
	u=[]
	v=[]
	w=[]
	p=[]
	for line in hist:
		line=line.strip()
		a=line.split()
		if len(a) < 6: continue
		a[1:]=[float(x) for x in a[1:]]
		t.append(a[1])
		u.append(a[2])
		v.append(a[3])
		w.append(a[4])
		p.append(a[5])
	print(directory,len(t),len(v),len(w))
	#clf()
	m=markers[nf]
	#plot(t,u,'r'+m,t,v,'g'+m,t,w,'b'+m,t,p,'k'+m)
	q=[math.sqrt(2*abs(x)) for x in p]
	#plot(t,v,'g'+m,t,w,'b'+m,t,q,'k'+m)
	#plot(t,v,'g'+m,t,w,'r'+m,t,q,'k'+m)
	plot(t,v,'g'+m,t,w,'r'+m,t,q,'k'+m,linewidth=1)
#	ts1=[59.,59.0]
#	ts2=[60.5,60.5]
#	plot(ts1,yy,'y'+m,ts2,yy,'y'+m,linewidth=3)
#	plot(ts1,yz,'y'+m,ts2,yz,'y'+m,linewidth=3)
	#plot(t,v,'k',t,w,'k--',t,q,'k:',linewidth=1)
	#plot(t,v,'k',t,w,'k--',t,q,'k:',xx,yy,'k:',linewidth=1)
#	plot(ts1,yy,'k'+m,ts2,yy,'k'+m,t,v,'g'+m,t,w,'r'+m,t,q,'k'+m,xx,yy,'b'+m,linewidth=3)
#	plot(t,v,'k',t,w,'k--',t,q,'k:',linewidth=1)
#	plot(t,v,'g'+m,t,w,'r'+m,t,q,'k'+m,linewidth=1)
#	plot(xx,yy,'k'+m,ts1,yy,'k'+m,linewidth=3)
#	plot(xx,yz,'k'+m,ts1,yz,'k'+m,linewidth=3)
	nf+=1
	legendlabs+=['s','w','q']
yy=[0.,.4]
yz=[ymax-.4,ymax]
if bar:
	ts1=[bar,bar]
	plot(ts1,yy,'b',linewidth=3)
	plot(ts1,yz,'b',linewidth=3)
l=legend(legendlabs,loc='best')
ylim([0,ymax])
if x1 and x2: xlim([x1,x2])
grid(True) #TEMPORARY
xlabel('t')
ax=gca()
ax.set_position([.1,.2,.85,.70]) #prevents tick labels from being chopped off
locs,labels=xticks()
#labels.size(18)
locs,labels=yticks(list(range(1,int(ymax+1))))
#labels.size(18)
if customtitle:
	title(thetitle)
else:
	title(', '.join(directories))
if outputfile:
	savefig(outputfile, dpi=dotsperinch, facecolor='w', edgecolor='w', orientation='portrait')
else:
	show()
