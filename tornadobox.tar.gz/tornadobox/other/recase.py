#!/usr/bin/env python
# Relabels the first 4 characters of files names.
# argv[1] is the new characters, the rest of argv could be *.sav or *.pkl
# example:  ./recase.py new1 *.pkl
import os, sys
from glob import glob
caze = sys.argv[1]
if len(caze)!=4: sys.exit('nope')
for file in sys.argv[2:]:
    newname = caze+file[4:]
    print(file,newname)
    os.rename(file,newname)


