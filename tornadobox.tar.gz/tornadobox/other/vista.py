#!/usr/bin/env python
import pyvista as pv
import numpy as np
import sys,pickle


try:
    filename=sys.argv[1]
except:
    print( "specify .pkl file from command line")
    sys.exit()
    
pinf=open(filename,'rb')

pkl = pickle.load(pinf)

print( pkl.keys() )

for i in pkl['parameters'].items():
    print(i)

# Note the transpose .T is essential for mayavi, which requires the
# volumes to be indexed with the three idices in x,y,z order.
# for plotters.py requires z,y,x order, so we do not append the .T method here
x = pkl['x']
y = pkl['y']
z = pkl['z']
u = pkl['u']
v = pkl['v']
w = pkl['w']
pp = pkl['pp']
time = pkl['parameters']['time']
rei = pkl['parameters']['rei']
swirl = pkl['parameters']['swirl']


print('x', x.shape, x.max(), x.min() )
print('y', y.shape, y.max(), y.min() )
print('z', z.shape, z.max(), z.min() )
print('u', u.shape, u.max(), u.min() )
print('v', v.shape, v.max(), v.min() )
print('w', w.shape, w.max(), w.min() )
print('pp', pp.shape, pp.max(), pp.min() )


## Create a 3D grid (e.g., 50x50x50)
#x, y, z = np.mgrid[-3:3:50j, -3:3:50j, -3:3:50j]

# Example scalar field, here we use a Gaussian function
#s2 = np.exp(-((x-2)**2 + y**2 + z**2))
#scalar_field = np.exp(-(x**2 + y**2 + z**2)) +s2
#pp = -np.exp(-(x**2 + y**2 + z**2)) 

# Create a StructuredGrid to hold the 3D scalar data
grid = pv.StructuredGrid(x, y, z)

# Add scalar data to the grid using point_data
grid.point_data['scalars'] = pp.T.flatten()  # Add scalar values to the grid

# Plot the isosurface at a specific scalar value
iso_value = -0.4  # Adjust the threshold as needed
contours = grid.contour([iso_value])  # Create isosurface

# Create the plotter and add the isosurface
plotter = pv.Plotter()
#plotter = pv.Plotter(off_screen=True)
plotter.add_mesh(contours, color='orange', opacity=0.7)  # Isosurface color and opacity


iso_value = -0.8  # Adjust the threshold as needed
contours = grid.contour([iso_value])  # Create isosurface
#plotter = pv.Plotter()
plotter.add_mesh(contours, color='green', opacity=1.0)  # Isosurface color and opacity

# Create the bounding box by defining the corners of the grid
bbox = pv.Cube(bounds=(x.min(), x.max(), y.min(), y.max(), z.min(), z.max()))

# Add the bounding box to the plot
#plotter.add_mesh(bbox, color='black', opacity=0.1, line_width=3)

# Add the bounding box as edges only
#plotter.add_mesh(bbox, color='black', opacity=1.0, line_width=3, show_edges=True)

# Create the edges of the bounding box manually using the `extract_edges` method
edges = bbox.extract_all_edges()

# Add the edges of the bounding box
#plotter.add_mesh(edges, color='black', line_width=3)

rectangle = pv.Plane(center=(0, 0, 0), i_size=1, j_size=1)
plotter.add_mesh(rectangle, color="lightblue", show_edges=True)

# Set custom camera position
zoom=1.
plotter.camera_position = [
    (0, -10*zoom, 2*zoom),   # Camera position
    (0, 0, 0),      # Focal point
    (0, 0, 1)       # View-up direction
]

plotter.show()
#plotter.show(screenshot='airplane.png')

