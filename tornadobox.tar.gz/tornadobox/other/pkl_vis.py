#!/usr/bin/env python

import pyvista as pv
import numpy as np
import pickle
import sys

def create_grid(x, y, z, data):
    """ Create a PyVista StructuredGrid from the given data. """
    grid = pv.StructuredGrid(x, y, z)
    grid.point_data['scalars'] = data.T.flatten()  
    return grid

def plot_data(grid, isovalues=[-0.8, -0.4], show_rectangle=True, outpng="", zoom=1.,zaim=.2):
    """ Plot the isosurfaces and an optional rectangle. """
    if outpng:
        plotter = pv.Plotter(off_screen=True,lighting='none')
    else:
        plotter = pv.Plotter(lighting='none')
    light = pv.Light()
    light.set_direction_angle(10, -60 )
#    light.ambient_color = 'green'  # Enable ambient light contribution, does not do anything?
    
    plotter.add_light(light)
#    plotter.enable_shadows()
    plotter.background_color = "black"
    default_lights = plotter.renderer.lights
    for i, light in enumerate(default_lights):
        print(f"Light {i}:")
        print(f"  Type: {light.light_type}")
        print(f"  Position: {light.position}")
        print(f"  Focal Point: {light.focal_point}")
        print(f"  Intensity: {light.intensity}")
#        print(f"  Color: {light.color}")
        print(f"  Ambient: {light.ambient_color}")
        print(f"  Specular: {light.specular_color}")
        print()
    

    for i, iso_value in enumerate(isovalues):
        contours = grid.contour([iso_value]) 
        if contours.n_points > 0:
            if i==0:
                color = 'red'
                opacity = 1.0
            elif i==1:
                color = 'yellow'
                opacity = .7
            else:
                color='white'
                opacity = .5
            plotter.add_mesh(contours, color=color, opacity=opacity)
        else:
            print(f"Skipping iso_value {iso_value}: No valid contours found.")

    # Add optional rectangle
    if show_rectangle:
        rectangle = pv.Plane(center=(0, 0, 0), i_size=.4, j_size=.4)
        plotter.add_mesh(rectangle, color="lightblue", show_edges=True)
#        rectangle2 = pv.Plane(center=(0, 0, 1), i_size=.4, j_size=.4)
#        edges = rectangle2.extract_all_edges()
#        plotter.add_mesh(edges, color="red", line_width=1)

    bbox = pv.Cube(bounds=(-2,2,-2,2,0,1))
#    bbox = pv.Cube(bounds=(-.2,.2,-.2,.2,0,1))
    edges = bbox.extract_all_edges()
#    plotter.add_mesh(edges, color='green', line_width=3)
            

    # Set custom camera position
    plotter.camera_position = [
        (0, -10 * zoom, 2 * zoom),
        (0, 0, zaim),
        (0, 0, 1)
    ]
    if outpng:
        plotter.show(screenshot=outpng)
        print('image to ',outpng)
    else:
        plotter.show()

def main():
    import argparse
    """ Main function to run the visualization from the command line. """
    # Define the argument parser
    parser = argparse.ArgumentParser(description="pyvista pkl files from tornadobox")

    # Positional arguments 
    parser.add_argument("pklfile", help="path to pkl file")
    parser.add_argument("field", nargs='?', default="pp" , help="field to plot")

    # Optional arguments
    parser.add_argument("-o", dest="oufn", type=str, default="", help="out image file name")
    parser.add_argument("-i", dest="iv", type=str, default="", help="isovalues, in quotes")
    parser.add_argument("-s", dest="show", action="store_true",  help="show plot")
    parser.add_argument("-z", dest="zoom", type=float, default=1., help="camera distance")

    # Version argument
    parser.add_argument("--version", action="version", version="0.1")

    # Parse arguments
    args = parser.parse_args()

    with open(args.pklfile, 'rb') as pinf:
        pkl = pickle.load(pinf)
    x = pkl['x']
    y = pkl['y']
    z = pkl['z']
    for key in pkl.keys():
        print(key,pkl[key].max())
    print( pkl['parameters'])
    f=args.field
    if args.iv:
        isov=[float(q) for q in args.iv.split('c')]
    elif f=='pp':
        isov=[-.5,-1.]
    elif f=='w':
        isov=[.5,1.]
    print(args.pklfile, f , isov) 
    grid = create_grid(x, y, z, pkl[f])
    plot_data(grid,isovalues=isov,outpng=args.oufn,zoom=args.zoom)

if __name__ == "__main__":
    main()

