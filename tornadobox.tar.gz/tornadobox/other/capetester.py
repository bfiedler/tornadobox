#!/usr/bin/env python
import numpy as np
import pickle
import sys

pklfile=sys.argv[1]
with open(pklfile,'rb') as pinf:
    pkl = pickle.load(pinf)
z = pkl['z']
b = pkl['b']
kmax,jmax,imax=z.shape
print(kmax,jmax,imax)
jc=(jmax+1)//2
ic=(imax+1)//2
zc = z[:,jc,ic]
deltaz = zc[1:]-zc[:-1]
bc = pkl['b'][:,jc,ic]
bca = (bc[1:]+bc[:-1])/2.
cape = np.dot(deltaz,bca)
print('buoyancy max:',pkl['b'].max(),'  CAPE=',cape)

