# 4 April  2014, v0.33
# should be compatible with both python2 and python3
# frame now removed from contour plot
#
# some really ugly plotting routines for use in METR 4323
# students may not need to look at this....
from __future__ import print_function
import pylab
import numpy as np

########################################
def pplot(*args,**kwargs):
# verbosity with **kwargs needed for compatibility with python2
    xlim=kwargs.get('xlim',None)
    ylim=kwargs.get('ylim',None)
    xlab=kwargs.get('xlab',None)
    ylab=kwargs.get('ylab',None)
    title=kwargs.get('title',None)
    outpng=kwargs.get('outpng','out.png')

    thefig=pylab.figure()
    theplot=thefig.add_subplot(1,1,1)
    theplot.plot(*args)
    if xlim!=None:  theplot.set_xlim(xlim)
    if ylim!=None:  theplot.set_ylim(ylim)
    if title!=None: theplot.set_title(title)
    if xlab!=None: theplot.set_xlabel(xlab)
    if ylab!=None: theplot.set_ylabel(ylab)
    thefig.savefig(outpng, dpi=72, facecolor='w', edgecolor='w', orientation='portrait')
    thefig.clf() # is this needed?

########################################

def pathit(xpath,ypath,x,y):
# xpath: array of x coordinate of curtain
# ypath: array of y coordinate of curtain
# x: grid of x coordiante in the model
# y: grid of y coordiante in the model
    ix=x.shape[-1]
    iy=x.shape[-2]
    lenpath=xpath.shape[0]
    ipath=np.zeros(lenpath,dtype='int')
    jpath=np.zeros(lenpath,dtype='int')
    fxa=np.zeros(lenpath)
    fya=np.zeros(lenpath)
    for n in range(lenpath):
        xx=xpath[n]
        yy=ypath[n]
        for i in range(ix):
            if xx <= x[0,0,i]: break
        for j in range(iy):
            if yy <= y[0,j,0]: break
        ipath[n]=i
        jpath[n]=j
        fxa[n]= (x[0,0,i]-xx) /( x[0,0,i] - x[0,0,i-1] )
        fya[n]= (y[0,j,0]-yy) /( y[0,j,0] - y[0,j-1,0] )
    # jpath and ipath: array indices of upper-right point of the grid box containing 
    # the (x,y) of the path point.  fx and fy are the fractional displacement, left and
    # down, from the grid point specified in ipath and jpath. fx and fy are between 0 and 1.
    # See how these are used in the interpolation defined within curtain.
    return ipath,jpath,fxa,fya

########################################

def curtain(ipath,jpath,fxa,fya,q):
# returns a curtain of q values at the heights available from q
# and the (x,y) positions defined by ipath, jpath, fxa and fya
    v = np.zeros( (q.shape[0], ipath.shape[0] ) ) #initial 2-D array 
    for n in range(len(ipath)):
        i=ipath[n]
        j=jpath[n]
        fx=fxa[n]
        fy=fya[n]
        # interpolate q to the curtain
        v[:,n] = (1-fy) * (q[:,j,i]*(1-fx) + q[:,j,i-1]*fx) \
               +     fy * (q[:,j-1,i]*(1-fx) + q[:,j-1,i-1]*fx)
    return v 


########################################
def oneplot(x,y,data,lowc=None,hic=None,dc=None,title=None,outpng=None,
    colorscheme='centerwhite',xstretch=1.,nlev=20,guiheight=8.,legend=True,
    u=None,v=None,plotvec=True,plotcl=True,vd=2,time=None,speed=None,dpi=144,
    text=None,verbose=0,angles='xy'):
    print('oneplot will write: ',outpng,' ,   for time=',time)
#    if u!=None:
    if u.any():
        assert u.shape==x.shape
        assert v.shape==x.shape
    aspectRatio=float( (y[-1,0]-y[0,0])/(x[0,-1]-x[0,0]) )
    plotheight=.7 #fraction of GUI window
#    xstretch=1. means isotropic distances 
    plotwidth=xstretch*plotheight/aspectRatio #fraction of GUI window if guiasp=1.
    dw=.1 # side margin
    dbt=.15 #bottom margin (leaves room for text note)
    cw=0.
    if legend: cw=.1
    guiwidth=(2*dw+plotwidth+2*cw)*guiheight
    guiasp=guiwidth/guiheight
    thefig=pylab.figure(figsize=(guiwidth,guiheight),facecolor='white')
    ax=thefig.add_axes([  dw/guiasp, dbt,  plotwidth/guiasp,  plotheight ],zorder=2.,frameon=False)

    colormap=pylab.cm.jet
    datamin=data.min()
    datamax=data.max()
    if lowc==None : lowc=datamin
    if hic==None :
        hic=datamax
        dc=(hic-lowc)/(nlev+1)
        hic=hic-.5*dc
        lowc=lowc+.5*dc
    if dc==None : dc=(hic-lowc)/nlev
    if dc<0: dc=-dc
    if hic<lowc:
        lowc,hic = hic,lowc
    contour=lowc
    mylevs=[]
    while contour < hic+.1*dc and len(mylevs)<100:
        mylevs.append(contour)
        contour+=dc
    nlev=len(mylevs)
    ncolors=nlev+1
    mycol=[niceColors(n/(ncolors-1.0),colorname=colorscheme) for n in range(0,ncolors)]
    mylevs=[-1.e30]+mylevs+[1.e30]
    if verbose>1: print(mylevs,mycol,len(mylevs),len(mycol))
    jres,ires=x.shape
    
    speedmax=0.
#    if u!=None and v!=None and plotvec==True:
    if u.any() and v.any() and plotvec==True:
        speedmax=np.sqrt(np.max(u*u+v*v))
        if verbose: print("speedmax:",speedmax)
        if speed==None:
             speedscale=speedmax*ires/vd 
             speed=speedmax
        else:
             speedscale=speed*ires/vd 
        if speedscale!=0.:    
            Q = pylab.quiver(x[::vd,::vd],y[::vd,::vd],u[::vd,::vd],v[::vd,::vd],
                scale=speedscale,units='width',angles=angles,zorder=11)
            speeds= "%7.3f"  % speed
            qk = pylab.quiverkey(Q, 0.95,-.05,speed, speeds, labelpos='W')
    p = pylab.contourf(x,y,data,mylevs,colors=mycol,antialiased=False) #cmap=colormap)
    if plotcl==True: p = pylab.contour(x,y,data,mylevs,colors=('k',),antialiased=False,zorder=10) #cmap=colormap)

    sleg=thefig.add_axes([(1.7*dw+plotwidth)/guiasp,dbt,cw/guiasp,plotheight])   
    sleg.set_axis_off()
    if verbose: print('min data: ',datamin,'   max data:',datamax)
    if verbose: print('low color bound:',lowc,'  high color bound:',hic)
    if  datamin<lowc:
        if verbose: print("warning: some data below low color bound ")
    if datamax>hic:
        if verbose: print("warning: some data above high color bound")
    if legend:
        midp=len(mylevs)//2
        dlevel=mylevs[midp]-mylevs[midp-1]
        formt=r'%6.2f'
        if dlevel<.11: formt=r'%6.3f'
        if dlevel<.0011: formt=r'%8.2e'
        labels=[formt % xx for xx in mylevs[1:-1]]
        nlab=len(labels)
        dy=1./(nlab+0)
        for i in range(0,len(labels)):
            regcolor=mycol[i]
            xrect=[0,1,1,0]
            ybot=max(0,(i-.5)*dy)
            ytop=min(1,(i+.5)*dy)
            yrect=[ybot,ybot,ytop,ytop]
            sleg.fill(xrect,yrect,facecolor=regcolor,edgecolor=regcolor,linewidth=0) #alt to above
            tcol='black'
            sleg.text(1.1, (i+.5)*dy   , labels[i],verticalalignment='center',color=tcol)
        regcolor=mycol[-1]
        yrect=[ytop,ytop,ytop+.5*dy,ytop+.5*dy]
        sleg.fill(xrect,yrect,facecolor=regcolor,edgecolor=regcolor,linewidth=0)
        for i in range(0,len(labels)):
            segcolor='k'
            #if mylevs[i+1]<0: segcolor='w'
            ytop=min(1,(i+.5)*dy)
            myline= pylab.Line2D([0,1],[ytop,ytop],color=segcolor,linewidth=2)
            if mylevs[i+1]<0: myline.set_dashes([5,5])
            sleg.add_line(myline)
    pylab.axes(ax)  # make the original axes current again
    pylab.clim(lowc,hic)
    dx=x[0,1]-x[0,0]
    dy=y[1,0]-y[0,0]
    pylab.axis( [ x[0,0]-dx, x[0,-1]+dx, y[0,0]-dy, y[-1,0]+dy ] )
    minstr= formt % datamin
    maxstr= formt % datamax
    speedm= "%7.3f"  % speedmax
    
    pylab.text(0.,1.05, minstr+' <',fontsize=24, transform = ax.transAxes)
    pylab.text(1.,1.05, '<'+maxstr,fontsize=24, transform = ax.transAxes,ha='right')
#    pylab.text(0.,-.1, 'max speed: '+speedm,fontsize=18, transform = ax.transAxes,ha='left')
    pylab.text(1.,1.12, 'max speed: '+speedm,fontsize=18, transform = ax.transAxes,ha='right')
    if title:
        pylab.text(.5,1.05, title,fontsize=36, transform = ax.transAxes,ha='center')
    if text:
        pylab.text(0.,-.1,text,fontsize=10, transform = ax.transAxes,ha='left')
    if verbose: print('time=',time)
    if time!=None:
        timestr= "time = %8.3f" % time
        pylab.text(.0,1.12, timestr,fontsize=24, transform = ax.transAxes,ha='left')
# pylab.title(title,fontsize=36)
    #Brian 2025
    pylab.xlim(-.25,.25)
    pylab.ylim(-.25,.25)
# end Brian
    if outpng==None:
        pylab.show()
    else:
        pylab.savefig(outpng, dpi=dpi, facecolor='w', edgecolor='w', orientation='portrait')
    pylab.show()
    thefig.clf()
    pylab.close()

######################################################
def niceColors(v,colorname='default'):
    v=max(v,0.)
    v=min(v,1.)
    if colorname=='cyan_magenta':
        green=1-v
        red=v
        blue=2*(max(green,red)-.5)
    elif colorname=='cyan_yellow':
        red=v
        blue=1-v
        green=max(red,blue)
    elif colorname=='cyan_mud_yellow':
        red=v
        blue=1-v
        green=max(red,blue)
        red=math.sqrt(red)
    elif colorname=='step':
        green=0
        if v>0.5:
            blue=1
            red=0
        else:
            blue=0
            red=1
    elif colorname=='fruity':
        ig=int(3*v)
        if ig==0:
            blue=1-.5*v
            green=3*v
            red=1.5*v+.5
        elif ig==1:
            blue=1-.5*v-.25
            green=2.-3*v
            red=.5*v+.25
        else:
            blue=1-.5*v-.5
            red=.5*v+.5
            green=3*v-2.
    elif colorname=='centerwhite':
        if (v < .5 ):
            q=(2*v)
            ex=q+(1-q)*.5
            q=q**ex
            red=12*(q*q*q/3-q*q/2+q/4)
            blue=1.
            green=3*q*q*(1-2*q/3)
        else: 
            s=(2-2*v)
            ex=s+(1-s)*.5
            s=s**ex
            blue=12*(s*s*s/3-s*s/2+s/4)
            red=1.
            green=3*s*s*(1-2*s/3)
    else:
        if not colorname=='default':
            print(colorname+' unknown, revert to default')
        red=v
        blue=1-v
        ig=int(v*4)
        if ig==0:
            green=1-4*v
        elif ig==1:
            green=2*(v-.25)
        elif ig==2:
            green=.5-2*(v-.5)
        else:
            green=4*(v-.75)
#    print colorname,v,red,green,blue
    return (red,green,blue)

# python modules tradiationally have some test function when executed
# from the command line: python3 plotters.py
if __name__=='__main__':
    print("this module is intended for import in METR 4323 ")     
