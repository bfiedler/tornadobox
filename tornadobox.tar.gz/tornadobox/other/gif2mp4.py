from moviepy.editor import VideoFileClip
#from moviepy import VideoFileClip

clip = VideoFileClip("anim.gif")
clip.write_videofile("output.mp4", codec="libx264")

