#!/usr/bin/env python
# 18 March 2025
import argparse
import math
#import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
SMALL_SIZE = 18
MEDIUM_SIZE = 24
BIGGER_SIZE = 36

plt.rc('font', size=SMALL_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=SMALL_SIZE)     # fontsize of the axes title
plt.rc('axes', labelsize=MEDIUM_SIZE)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
plt.rc('ytick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
plt.rc('legend', fontsize=SMALL_SIZE)    # legend fontsize
plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title


# Define the argument parser
parser = argparse.ArgumentParser(description="plots history file from tornadobox")

# Positional arguments (like npyfile1 and optional npyfile2)
parser.add_argument("histfile", help="path to history file")
parser.add_argument("histfile2", nargs='?', default="", help="path to history file")

# Optional arguments
parser.add_argument("-o", dest="oufn", type=str, default="", help="out image file name")
parser.add_argument("-t", dest="title", type=str, default="", help="plot title")
parser.add_argument("-s", dest="show", action="store_true",  help="show plot")
parser.add_argument("-ymax", dest="ymax", type=float, default=4, help="max on y axis")
parser.add_argument("-tmax", dest="tmax", type=float, help="max on t axis")
parser.add_argument("-stime", dest="stime", type=float, default=None, help="mark special time")

# Version argument
parser.add_argument("--version", action="version", version="0.1")

# Parse arguments
args = parser.parse_args()
plt.rcParams["figure.figsize"] = (10,10)

lines=open(args.histfile,'r').readlines()
ap=lines[0:100] #stored parameters of model run

sa=[]
ta=[]
dta=[]
sa=[]
wa=[]
pa=[]
qa=[]
look = len(lines[0].split())
if look==6:
    i=0
else:
    i=100

for line in lines[i:]:
    n,t,dt,s,w,p = [float(x) for x in line.split()]
    ta.append(t)
    dta.append(dt)
    sa.append(s)
    wa.append(w)
    pa.append(p)
    qa.append(math.sqrt(abs(2*p)))


plt.plot(ta,sa,'c--',label='s',lw=2,zorder=1)
plt.plot(ta,wa,'m--',label='w',lw=2,zorder=2)
plt.plot(ta,qa,'y--',label='q',lw=2,zorder=3)

####################  plot second hist file, if available #############
if args.histfile2:
    lines=open(args.histfile2,'r').readlines()
    ap=lines[0:100] #skip stored parameters of model run

    sa=[]
    ta=[]
    dta=[]
    sa=[]
    wa=[]
    pa=[]
    qa=[]
    look = len(lines[0].split())
    if look==6:
        i=0
    else:
        i=100

    for line in lines[i:]:
        n,t,dt,s,w,p = [float(x) for x in line.split()]
        ta.append(t)
        dta.append(dt)
        sa.append(s)
        wa.append(w)
        pa.append(p)
        qa.append(math.sqrt(abs(2*p)))


    plt.plot(ta,sa,'g',label='s',lw=1,zorder=10)
    plt.plot(ta,wa,'r',label='w',lw=1,zorder=11)
    plt.plot(ta,qa,'k',label='q',lw=1,zorder=12)


################# make vertical marks at stime ###########

if args.stime:
    yy=[0.,.4]
    yz=[args.ymax-.4,args.ymax]
    ts1=[args.stime,args.stime]
    plt.plot(ts1,yy,'b',linewidth=3)
    plt.plot(ts1,yz,'b',linewidth=3)

############### finish labels #########################

plt.legend()
plt.grid()
plt.ylim([0,args.ymax])
if args.tmax: plt.xlim([0,args.tmax])

if not args.title:
    title=args.histfile.split('/')[-1]
    title=title.replace('.hist','')
    if args.histfile2:
        title2=args.histfile2.split('/')[-1]
        title2=title2.replace('.hist','')
        title += '  '+title2
    print(title)
    args.title=title
plt.title(args.title)
plt.xlabel('t')

if not args.oufn:
    args.oufn = args.histfile.replace('.hist','.png')

plt.savefig(args.oufn)
print('saved file ',args.oufn)

if args.show: plt.show()
plt.close()

