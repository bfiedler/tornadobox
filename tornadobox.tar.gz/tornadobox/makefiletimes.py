#!/usr/bin/env python
# 18 March 2025
# prints out sequential times for which to dump .sav files
# example: ./makefiletimes.py 0 200 .1 > filetimes.txt
# In earlier years, saving file space was important and
# it was possible to edit a custom filetimes.txt to save
# more .sav files during a time of interest.  Now only the 
# third number is important. 200 should be larger than
# the tstop, 0 should be, well, 0....
import sys
a,b,c=[float(x) for x in sys.argv[1:]]
f=a
while f<b:
	s='%7.2f' % f
	print(s)
	f+=c

