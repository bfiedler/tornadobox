#!/usr/bin/env python
# 18 March 2025
from moviepy import * 
from glob import glob
import sys,os
import argparse

# Define the argument parser
parser = argparse.ArgumentParser(description="output mp4 from png files, with optional title")

# Positional arguments 
parser.add_argument("head", help="path to glob for png files")

# Optional arguments
parser.add_argument("-o", dest="outmp4", type=str, default="video.mp4", help="output mp4 file name")
parser.add_argument("-t", dest="title", type=str, default="", help="path to png for title")
parser.add_argument("-n", dest="ttitle", type=int, default=3 , help=" seconds to show title" )
args = parser.parse_args()

if args.title and not os.path.exists(args.title):
    sys.exit(args.title+' not found')

if os.path.exists(args.outmp4):
    permit= input(args.outmp4+' exists, overwrite? (y/n)')
    if permit !='y': sys.exit("quitting")

lookpng=args.head+"*.png"
files = glob(lookpng)
files.sort()
if len(files)==0: sys.exit("no PNG files in "+lookpng)
print(files)

# Create video from the image sequence
image_clip = ImageSequenceClip(files, fps=4)

if args.title:
# Create a clip for the title image (displayed for ttitle seconds)
    title_clip = ImageClip(args.title, duration=args.ttitle)
# Concatenate title clip with the main video
    final_clip = concatenate_videoclips([title_clip, image_clip])
else:
    final_clip=image_clip

# Export final video
final_clip.write_videofile(args.outmp4, fps=24)

