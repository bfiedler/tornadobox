#!/usr/bin/env python
# 18 March 2025 
# usage: ./sav2pkl.py anyfile.sav
# or for many files: ./sav2pkl.py *.sav
import numpy as np
import sys,pickle,os


def nextarray(longarray,sz,istart):
    ilen = 1
    for k in sz:
        ilen = ilen * k
    iend = istart + ilen
    nextarray = longarray[istart:iend].copy()
    nextarray.resize(sz)
#    print( nextarray.min(),nextarray.max() )
    return nextarray,iend

files=sys.argv[1:]
files.sort()
for filename in files:
    if 'restart' in filename: continue
    pfile=filename.replace('.sav','.pkl')
    if os.path.exists(pfile):
        print(pfile,' already exists, skip')
        continue
    inf=open(filename,'rb')
    allofit=inf.read()
    inf.close()
    # fortan file has extra 4 bytes at beginning and end, so strip off:
#    r=np.fromstring(allofit[4:-4],dtype='f') #deprecated
    r=np.frombuffer(allofit[4:-4],dtype='f')
    del allofit # ... reduce memory needs
    # for reference, the fortran write in boxn.f was: 
    # write (69) ap,x,y,z,b,u,v,w,pp,p,vnu,dudt,dvdt,dwdt
    ap=r[0:100].copy()
#    print(ap)
    inext=100
    # these four characters were stuffed into a float in an ad hoc way:
#    caseprefix = ap[-6].tostring() # deprecated
    caseprefix = ap[-6].tobytes()
#    print('caseprefix:',caseprefix)

    apl=ap.tolist()
    names='rei,reit,swirl,dtmax,alim,diff,pit,rlx,gamma,slip,order,ex2,ex3,ex4,time,cput,steps,dt,dt1,dt2'.split(',')

    pairs=zip(names,apl[0:len(names)])

    parameters={}
    parameters['caseprefix'] = caseprefix
    for v,x in pairs:
#        print('%s = %10.3e' % (v,x) )
        parameters[v]=x


    fortran_in=int(ap[-3])
    fortran_jn=int(ap[-2])
    fortran_kn=int(ap[-1])
    parameters['fortran_in']=fortran_in
    parameters['fortran_jn']=fortran_jn
    parameters['fortran_kn']=fortran_kn

    forpkl={}
    forpkl['parameters']=parameters

    sz=(fortran_kn,fortran_jn,fortran_in)
    szp=(fortran_kn-1,fortran_jn-1,fortran_in-1)
    usize=sz[0]*sz[1]*sz[2]

    x,inext = nextarray(r,sz,inext)
    forpkl['x']=x

    y,inext = nextarray(r,sz,inext)
    forpkl['y']=y

    z,inext = nextarray(r,sz,inext)
    forpkl['z']=z

    b,inext = nextarray(r,sz,inext)
    forpkl['b']=b

    u,inext = nextarray(r,sz,inext)
    forpkl['u']=u

    v,inext = nextarray(r,sz,inext)
    forpkl['v']=v

    w,inext = nextarray(r,sz,inext)
    forpkl['w']=w

    pp,inext = nextarray(r,sz,inext)
    forpkl['pp']=pp

    p,inext = nextarray(r,szp,inext)
    forpkl['p']=p

    vnu,inext = nextarray(r,(fortran_kn,),inext)
    forpkl['vnu']=vnu

    print(' writing pickle file',pfile)
    pouf=open(pfile,'wb')
    pickle.dump(forpkl,pouf,-1)
